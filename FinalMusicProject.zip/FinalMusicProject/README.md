# FinalMusicProject

Music Instrument Detection using Machine Learning Python 

Audio Dataset files are in audio folder 

Install packages 

Run It
